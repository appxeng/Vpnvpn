package app.myvpn

import android.content.Context

/** ذخیرهٔ تنظیمات و لیست سرورها */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("myvpn", Context.MODE_PRIVATE)

    companion object {
        const val SPLIT_ALL = 0       // همهٔ برنامه‌ها از VPN
        const val SPLIT_ONLY = 1      // فقط برنامه‌های انتخابی از VPN
        const val SPLIT_EXCEPT = 2    // همه به‌جز برنامه‌های انتخابی
        const val DEFAULT_DNS = "1.1.1.1,8.8.8.8"
    }

    /** سرورهایی که خود کاربر اضافه کرده */
    var links: List<String>
        get() = sp.getString("links", "")!!.split("\n").filter { it.isNotBlank() }
        set(v) = sp.edit().putString("links", v.joinToString("\n")).apply()

    /** سرورهای رایگانِ پیداشده (با هر بروزرسانی جایگزین می‌شوند) */
    var freeLinks: List<String>
        get() = sp.getString("free_links", "")!!.split("\n").filter { it.isNotBlank() }
        set(v) = sp.edit().putString("free_links", v.joinToString("\n")).apply()

    var lastGood: String?
        get() = sp.getString("last_good", null)
        set(v) = sp.edit().putString("last_good", v).apply()

    var wantConnected: Boolean
        get() = sp.getBoolean("want", false)
        set(v) = sp.edit().putBoolean("want", v).apply()

    var dns: String
        get() = sp.getString("dns", DEFAULT_DNS)!!
        set(v) = sp.edit().putString("dns", v).apply()

    var splitMode: Int
        get() = sp.getInt("split_mode", SPLIT_ALL)
        set(v) = sp.edit().putInt("split_mode", v).apply()

    var splitApps: Set<String>
        get() = sp.getStringSet("split_apps", emptySet())!!.toSet()
        set(v) = sp.edit().putStringSet("split_apps", v).apply()

    /** اگر سرور سالمی نبود، خودکار سرور رایگان بگیر */
    var autoFree: Boolean
        get() = sp.getBoolean("auto_free", true)
        set(v) = sp.edit().putBoolean("auto_free", v).apply()

    fun dnsList(): List<String> =
        dns.split(Regex("[,;\\s]+")).filter { it.isNotBlank() }.ifEmpty { DEFAULT_DNS.split(",") }

    /** همهٔ سرورها: ابتدا سرورهای خود کاربر، بعد رایگان‌ها */
    fun servers(): List<Server> {
        val mine = links.mapNotNull { ConfigParser.parse(it) }
        val mineLinks = links.toSet()
        val free = freeLinks.filter { it !in mineLinks }
            .mapNotNull { ConfigParser.parse(it)?.also { s -> s.free = true } }
        return mine + free
    }
}
