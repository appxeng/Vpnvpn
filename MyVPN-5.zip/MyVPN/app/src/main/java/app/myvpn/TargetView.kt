package app.myvpn

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.core.content.res.ResourcesCompat
import kotlin.math.*

/** سیبل + تیر + درصد؛ هنگام اتصال تیر به خال سیبل می‌خورد و عقاب روی سیبل می‌نشیند */
class TargetView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {

    enum class S { IDLE, CONNECTING, CONNECTED }

    private var state = S.IDLE
    private var prog = 0f          // ۰..۱ مسیر تیر
    private var eagle = 0f         // ۰..۱ ورود عقاب
    private var ripple = 0f        // ۰..۱ موج برخورد
    private var anim: ValueAnimator? = null
    private val extra = mutableListOf<ValueAnimator>()

    private val dp = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val head = BitmapFactory.decodeResource(resources, R.drawable.eagle_head)
    private val font: Typeface = Typeface.DEFAULT_BOLD

    fun setState(s: S) {
        if (s == state) return
        state = s
        anim?.cancel()
        extra.forEach { it.cancel() }; extra.clear()
        when (s) {
            S.IDLE -> {
                anim = ValueAnimator.ofFloat(prog, 0f).apply {
                    duration = 400; addUpdateListener { prog = it.animatedValue as Float; eagle = min(eagle, prog); invalidate() }; start()
                }
                eagle = 0f; ripple = 0f
            }
            S.CONNECTING -> {
                eagle = 0f; ripple = 0f
                anim = ValueAnimator.ofFloat(prog, 0.92f).apply {
                    duration = 7000; interpolator = DecelerateInterpolator(1.6f)
                    addUpdateListener { prog = it.animatedValue as Float; invalidate() }; start()
                }
            }
            S.CONNECTED -> {
                anim = ValueAnimator.ofFloat(prog, 1f).apply {
                    duration = 350
                    addUpdateListener { prog = it.animatedValue as Float; invalidate() }
                    addListener(object : android.animation.AnimatorListenerAdapter() {
                        private var cancelled = false
                        override fun onAnimationCancel(an: android.animation.Animator) { cancelled = true }
                        override fun onAnimationEnd(an: android.animation.Animator) { if (!cancelled) hit() }
                    }); start()
                }
            }
        }
    }

    private fun hit() {
        extra += ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900; addUpdateListener { ripple = it.animatedValue as Float; invalidate() }; start()
        }
        extra += ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 650; interpolator = OvershootInterpolator(2f); startDelay = 150
            addUpdateListener { eagle = it.animatedValue as Float; invalidate() }; start()
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        val s = min(MeasureSpec.getSize(w), (340 * dp).toInt())
        setMeasuredDimension(s, (s * 1.12f).toInt())
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val R = w * 0.40f
        val cy = height * 0.50f - 6 * dp

        // هالهٔ شیشه‌ای
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, R * 1.25f, intArrayOf(0x552BC0D3, 0x002BC0D3), null, Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, R * 1.25f, p); p.shader = null

        // حلقه‌های سیبل
        val cols = intArrayOf(0xCCFFFFFF.toInt(), 0xCCBFE9EF.toInt(), 0xCCFFFFFF.toInt(), 0xCC8ED6E1.toInt(), 0xCCFFFFFF.toInt())
        val rs = floatArrayOf(1f, 0.8f, 0.6f, 0.4f, 0.2f)
        for (i in rs.indices) { p.color = cols[i]; cv.drawCircle(cx, cy, R * rs[i], p) }
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * dp; p.color = 0xFF1596AB.toInt()
        for (r in rs) cv.drawCircle(cx, cy, R * r, p)
        p.style = Paint.Style.FILL; p.color = 0xFFF2B544.toInt(); cv.drawCircle(cx, cy, R * 0.09f, p)

        // حلقهٔ پیشرفت
        p.style = Paint.Style.STROKE; p.strokeWidth = 7 * dp; p.strokeCap = Paint.Cap.ROUND
        p.color = 0x330B5A6E
        val rr = R + 14 * dp
        val box = RectF(cx - rr, cy - rr, cx + rr, cy + rr)
        cv.drawArc(box, 0f, 360f, false, p)
        p.color = if (state == S.CONNECTED) 0xFF1596AB.toInt() else 0xFF2BC0D3.toInt()
        cv.drawArc(box, -90f, 360f * prog, false, p)

        // موج برخورد
        if (ripple in 0.01f..0.99f) {
            p.strokeWidth = 3 * dp; p.color = ((1f - ripple) * 180).toInt() shl 24 or 0x1596AB
            cv.drawCircle(cx, cy, R * (0.1f + ripple * 0.9f), p)
        }

        // تیر
        if (state != S.IDLE || prog > 0.01f) drawArrow(cv, cx, cy, R)

        // عقاب نشسته روی سیبل
        if (eagle > 0.01f) {
            val er = R * 0.30f * eagle
            val ex = cx; val ey = cy - rr - er * 0.35f
            p.style = Paint.Style.FILL; p.color = 0x55000000; cv.drawCircle(ex, ey + 4 * dp, er, p)
            val save = cv.save()
            val path = Path().apply { addCircle(ex, ey, er, Path.Direction.CW) }
            cv.clipPath(path)
            cv.drawBitmap(head, null, RectF(ex - er, ey - er, ex + er, ey + er), p)
            cv.restoreToCount(save)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * dp; p.color = 0xFFFFFFFF.toInt(); cv.drawCircle(ex, ey, er, p)
        }

        // درصد
        p.style = Paint.Style.FILL; p.typeface = font; p.textAlign = Paint.Align.CENTER
        p.color = if (state == S.CONNECTED) 0xFF0B5A6E.toInt() else 0xFF0B3B4A.toInt()
        p.textSize = 40 * dp
        cv.drawText("${(prog * 100).roundToInt()}٪".toPersian(), cx, height - 10 * dp, p)
    }

    private fun drawArrow(cv: Canvas, cx: Float, cy: Float, R: Float) {
        val sx = cx - R * 1.55f; val sy = cy + R * 1.55f      // نقطهٔ شروع بیرون سیبل
        val ease = 1f - (1f - prog).pow(2)
        val tx = sx + (cx - sx) * (0.15f + 0.85f * ease)
        val ty = sy + (cy - sy) * (0.15f + 0.85f * ease)
        val ang = atan2(cy - sy, cx - sx)
        val len = R * 0.95f
        val bx = tx - cos(ang) * len; val by = ty - sin(ang) * len
        val nx = -sin(ang); val ny = cos(ang)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 4.5f * dp; p.color = 0xFF0B3B4A.toInt(); cv.drawLine(bx, by, tx, ty, p)
        // پر
        p.style = Paint.Style.FILL; p.color = 0xFF1596AB.toInt()
        for (k in 0..2) {
            val fx = bx + cos(ang) * k * 9 * dp; val fy = by + sin(ang) * k * 9 * dp
            val path = Path().apply {
                moveTo(fx, fy); lineTo(fx - cos(ang) * 14 * dp + nx * 9 * dp, fy - sin(ang) * 14 * dp + ny * 9 * dp)
                lineTo(fx + cos(ang) * 8 * dp, fy + sin(ang) * 8 * dp); close()
                moveTo(fx, fy); lineTo(fx - cos(ang) * 14 * dp - nx * 9 * dp, fy - sin(ang) * 14 * dp - ny * 9 * dp)
                lineTo(fx + cos(ang) * 8 * dp, fy + sin(ang) * 8 * dp); close()
            }
            cv.drawPath(path, p)
        }
        // نوک
        p.color = 0xFFF2B544.toInt()
        val head = Path().apply {
            moveTo(tx + cos(ang) * 4 * dp, ty + sin(ang) * 4 * dp)
            lineTo(tx - cos(ang) * 12 * dp + nx * 7 * dp, ty - sin(ang) * 12 * dp + ny * 7 * dp)
            lineTo(tx - cos(ang) * 12 * dp - nx * 7 * dp, ty - sin(ang) * 12 * dp - ny * 7 * dp); close()
        }
        cv.drawPath(head, p)
    }

    private fun String.toPersian(): String =
        map { if (it in '0'..'9') ('۰' + (it - '0')) else it }.joinToString("")
}
