package app.myvpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Handler
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray

/**
 * منطق پایداری:
 *  1) همیشه یک «استخر» از ۳ سرور تست‌شده در هسته بارگذاری است (اصلی + ۲ جایگزین آماده).
 *     خود Xray با balancer(leastPing) در صورت افت یا مرگ ناگهانی سرور فعال، فوراً به جایگزین می‌رود.
 *  2) یک watchdog هر ۱۵ ثانیه کیفیت سرور اصلی را می‌سنجد. اگر ضعیف شد (قبل از قطع کامل)،
 *     سرورهای دیگر را تست می‌کند، بهترین را پیدا می‌کند و استخر جدید را «اول آماده، بعد جایگزین» می‌کند.
 *  3) تونل (TUN) هنگام تعویض بسته نمی‌شود تا ترافیک بدون VPN نشت نکند.
 */
class MyVpnService : VpnService(), CoreCallbackHandler {

    companion object {
        const val ACTION_START = "app.myvpn.START"
        const val ACTION_STOP = "app.myvpn.STOP"
        const val EXTRA_LINK = "link"
        private const val POOL_SIZE = 3
        private const val CHECK_EVERY_MS = 15_000L
        private const val COOLDOWN_MS = 30_000L
        private val IPV4 = Regex("^(\\d{1,3}\\.){3}\\d{1,3}$")
        private val IPV6 = Regex("^[0-9a-fA-F:]+$")

        @Volatile var running = false
        @Volatile var lastState = ""
        var onState: ((String) -> Unit)? = null
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val swapLock = Mutex()
    private var tun: ParcelFileDescriptor? = null
    private var core: CoreController? = null
    private var pool: List<Server> = emptyList()
    private var baseline = 0L
    private var mainJob: Job? = null
    private var watchdog: Job? = null
    private lateinit var store: Store

    override fun onCreate() {
        super.onCreate()
        store = Store(this)
        Libv2ray.initCoreEnv(filesDir.absolutePath, "")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when {
            intent?.action == ACTION_STOP -> {
                store.wantConnected = false
                mainJob?.cancel()
                stopAll()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            intent == null && !store.wantConnected -> stopSelf()
            else -> {
                startForeground(1, notification("در حال اتصال…"))
                store.wantConnected = true
                val link = intent?.getStringExtra(EXTRA_LINK)   // فقط وقتی کاربر خودش سروری را انتخاب کرده
                mainJob?.cancel()
                mainJob = scope.launch { connectBestOrGiven(link) }
            }
        }
        return START_STICKY
    }

    // ───────────────────────── اتصال اولیه ─────────────────────────

    private suspend fun connectBestOrGiven(preferredLink: String?) {
        watchdog?.cancel()
        var triedFree = false
        var failures = 0
        while (currentCoroutineContext().isActive && store.wantConnected) {
            var all = store.servers()
            if (all.isEmpty() && store.autoFree && !triedFree) {
                triedFree = true
                postState("سروری ندارید؛ در حال یافتن سرور رایگان…")
                FreeServers.refresh(store) { postState(it) }
                all = store.servers()
            }
            if (all.isEmpty()) {
                postState("سروری وجود ندارد؛ لینک اضافه کنید")
                delay(8000); continue
            }

            postState("در حال تست پینگ سرورها…")
            Pinger.testAll(all)
            val ranked = Pinger.sorted(all).filter { it.pingMs > 0 }

            if (ranked.isNotEmpty()) {
                val first = preferredLink?.let { p -> ranked.find { it.link == p } }
                val newPool = (listOfNotNull(first) + ranked.filter { it !== first }).take(POOL_SIZE)
                if (startPool(newPool)) { startWatchdog(); return }
            } else if (store.autoFree && !triedFree) {
                triedFree = true
                postState("سرورها پاسخ نمی‌دهند؛ یافتن سرور رایگان جدید…")
                FreeServers.refresh(store) { postState(it) }
                continue
            }
            failures++
            if (failures % 4 == 0) triedFree = false   // هر چند بار یک‌بار دوباره سراغ سرور رایگان برو
            postState("هیچ سروری وصل نشد؛ تلاش دوباره…")
            delay(8000)
        }
    }

    // ───────────────────────── استخر و هسته ─────────────────────────

    /** استخر را اجرا می‌کند؛ اگر کل استخر بالا نیامد تک‌تک امتحان می‌کند */
    private suspend fun startPool(newPool: List<Server>): Boolean = swapLock.withLock {
        val attempts = if (newPool.size > 1) listOf(newPool) + newPool.map { listOf(it) } else listOf(newPool)
        for (p in attempts) {
            if (launchCore(p)) {
                pool = p
                baseline = p[0].pingMs
                running = true
                store.lastGood = p[0].link
                val msg = "وصل: ${p[0].name} (${p[0].pingMs}ms) · ${p.size - 1} جایگزین آماده"
                postState(msg)
                updateNotification(msg)
                return@withLock true
            }
        }
        false
    }

    /**
     * ابتدا تونل جدید ساخته می‌شود (اندروید جایگزین تونل قبلی می‌کند و ترافیک هیچ لحظه بدون VPN نمی‌ماند)،
     * سپس هستهٔ قبلی متوقف و هستهٔ جدید با استخر جدید بالا می‌آید.
     */
    private fun launchCore(p: List<Server>): Boolean {
        val newTun = buildTun() ?: return false
        val old = tun
        tun = newTun
        stopCore()
        runCatching { old?.close() }
        return try {
            val ctl = Libv2ray.newCoreController(this)
            ctl.startLoop(ConfigParser.fullConfig(p, store.dnsList()), newTun.fd)
            core = ctl
            true
        } catch (e: Exception) {
            postState("خطا در راه‌اندازی هسته: ${e.message}")
            false
        }
    }

    private fun buildTun(): ParcelFileDescriptor? {
        val b = Builder()
            .setSession("MyVPN")
            .setMtu(1500)
            .addAddress("172.19.0.1", 30)
            .addAddress("fd00::1", 126)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)

        // DNS دلخواه کاربر
        val ips = store.dnsList().filter { IPV4.matches(it) || (it.contains(':') && IPV6.matches(it)) }
            .ifEmpty { listOf("1.1.1.1") }
        ips.forEach { runCatching { b.addDnsServer(it) } }

        // تونل برای برنامه‌های انتخابی
        val apps = store.splitApps
        when {
            store.splitMode == Store.SPLIT_ONLY && apps.isNotEmpty() ->
                apps.forEach { runCatching { b.addAllowedApplication(it) } }
            store.splitMode == Store.SPLIT_EXCEPT -> {
                apps.forEach { runCatching { b.addDisallowedApplication(it) } }
                runCatching { b.addDisallowedApplication(packageName) }
            }
            else -> runCatching { b.addDisallowedApplication(packageName) } // سوکت‌های خود هسته از تونل رد نشوند
        }
        return b.establish()
    }

    private fun stopCore() {
        runCatching { core?.stopLoop() }
        core = null
        running = false
    }

    private fun stopAll() {
        watchdog?.cancel()
        stopCore()
        runCatching { tun?.close() }
        tun = null
        postState("قطع شد")
    }

    // ───────────────────────── مانیتور کیفیت ─────────────────────────

    private fun startWatchdog() {
        watchdog?.cancel()
        watchdog = scope.launch {
            var weak = 0
            var coolUntil = System.currentTimeMillis() + COOLDOWN_MS / 2
            while (isActive) {
                delay(CHECK_EVERY_MS)
                val primary = pool.firstOrNull() ?: continue
                val ms = Pinger.measure(primary)
                val failed = ms <= 0

                // میانگین کیفیت «خوب» را به‌عنوان مبنا نگه می‌داریم
                if (!failed && (baseline <= 0 || ms < baseline * 3 / 2)) {
                    baseline = if (baseline <= 0) ms else (baseline * 3 + ms) / 4
                }
                val degraded = failed || ms > maxOf(1200L, baseline * 5 / 2)
                weak = if (degraded) weak + (if (failed) 2 else 1) else 0

                if (weak >= 2 && System.currentTimeMillis() >= coolUntil) {
                    weak = 0
                    val swapped = proactiveSwap(primary, if (failed) Long.MAX_VALUE else ms)
                    coolUntil = System.currentTimeMillis() + COOLDOWN_MS
                    if (!swapped && failed) {
                        // هیچ جایگزینی پیدا نشد و سرور اصلی مرده: از اول، با یافتن سرور رایگان
                        mainJob = scope.launch { connectBestOrGiven(null) }
                        return@launch
                    }
                }
            }
        }
    }

    /** قبل از قطع کامل: بهترین جایگزین را پیدا و آماده می‌کند، بعد استخر را عوض می‌کند */
    private suspend fun proactiveSwap(current: Server, currentMs: Long): Boolean {
        postState("اتصال ضعیف شد؛ آماده‌سازی سرور جایگزین…")
        val others = store.servers().filter { it.link != current.link }
        val standbyLinks = pool.drop(1).map { it.link }.toSet()
        val standby = others.filter { it.link in standbyLinks }
        val sample = others.filter { it.link !in standbyLinks }.shuffled().take(10)
        val cands = standby + sample
        Pinger.testAll(cands)
        val ok = cands.filter { it.pingMs > 0 }.sortedBy { it.pingMs }
        val best = ok.firstOrNull()

        val worthIt = best != null && (currentMs == Long.MAX_VALUE || best.pingMs < currentMs * 7 / 10)
        if (!worthIt) {
            postState("جایگزین بهتری پیدا نشد؛ ادامه با همین سرور")
            if (store.autoFree) {
                // در پس‌زمینه سرور رایگان تازه بگیر تا دفعهٔ بعد گزینهٔ بیشتری باشد
                scope.launch { FreeServers.refresh(store) { } }
            }
            return false
        }
        val newPool = (listOf(best!!) + ok.filter { it !== best }).take(POOL_SIZE)
        val done = startPool(newPool)
        if (done) postState("تعویض خودکار انجام شد: ${best.name} (${best.pingMs}ms)")
        return done
    }

    // ───────────────────────── سیستم ─────────────────────────

    override fun onRevoke() {
        store.wantConnected = false
        mainJob?.cancel()
        stopAll()
        stopSelf()
    }

    override fun onDestroy() {
        scope.cancel()
        stopAll()
        super.onDestroy()
    }

    // CoreCallbackHandler
    override fun startup(): Long = 0
    override fun shutdown(): Long = 0
    override fun onEmitStatus(code: Long, msg: String?): Long = 0

    private fun postState(text: String) {
        lastState = text
        onState?.let { cb -> Handler(mainLooper).post { cb(text) } }
    }

    private fun notification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vpn", "VPN", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "vpn")
            .setContentTitle("MyVPN").setContentText(text)
            .setSmallIcon(R.drawable.ic_eagle_notif)
            .setContentIntent(pi).setOngoing(true).build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, notification(text))
    }
}
