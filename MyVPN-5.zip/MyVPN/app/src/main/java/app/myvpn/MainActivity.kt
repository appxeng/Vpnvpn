package app.myvpn

import android.Manifest
import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var store: Store
    private lateinit var adapter: ArrayAdapter<String>
    private var servers: List<Server> = emptyList()   // همهٔ سرورها (اشیای پایدار برای ثبت پینگ)
    private var shown: List<Server> = emptyList()     // ترتیب نمایش داده‌شده در لیست
    private lateinit var status: TextView
    private lateinit var btnConnect: Button
    private lateinit var btnFree: Button
    private lateinit var target: TargetView
    private var pendingLink: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)
        status = findViewById(R.id.status)
        btnConnect = findViewById(R.id.btnConnect)
        btnFree = findViewById(R.id.btnFree)
        target = findViewById(R.id.target)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        findViewById<ListView>(R.id.list).apply {
            adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> connect(shown[pos].link) }
        }

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)

        btnConnect.setOnClickListener {
            if (MyVpnService.running) disconnect() else connect(null)
        }
        findViewById<Button>(R.id.btnPing).setOnClickListener { pingAll() }
        findViewById<Button>(R.id.btnAdd).setOnClickListener { addDialog() }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            store.links = emptyList(); store.freeLinks = emptyList(); reload()
        }
        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        btnFree.setOnClickListener { findFree() }

        MyVpnService.onState = { text ->
            status.text = text
            if (!MyVpnService.running && !text.contains("در حال")) connecting = false
            updateConnectButton()
        }
        reload()
        // اتصال خودکار هنگام باز شدن اپ اگر کاربر آخرین بار وصل بوده
        if (store.wantConnected && !MyVpnService.running) connect(null)
    }

    override fun onResume() {
        super.onResume()
        reload()
        if (MyVpnService.lastState.isNotEmpty()) status.text = MyVpnService.lastState
        updateConnectButton()
    }

    private var connecting = false

    private fun updateConnectButton() {
        val run = MyVpnService.running
        if (run) connecting = false
        btnConnect.text = if (run) "قطع اتصال" else "اتصال سریع (بهترین پینگ)"
        target.setState(when { run -> TargetView.S.CONNECTED; connecting -> TargetView.S.CONNECTING; else -> TargetView.S.IDLE })
    }

    /** لیست را از حافظه می‌خواند و پینگ‌های قبلی را حفظ می‌کند */
    private fun reload() {
        val old = servers.associateBy { it.link }
        servers = store.servers().onEach { n -> old[n.link]?.let { n.pingMs = it.pingMs } }
        render()
    }

    /** فقط نمایش؛ اشیای servers را دست نمی‌زند */
    private fun render() {
        shown = Pinger.sorted(servers)
        adapter.clear()
        adapter.addAll(shown.map {
            val p = when { it.pingMs > 0 -> "${it.pingMs} ms"; it.pingMs == 0L -> "…"; else -> "—" }
            val tag = if (it.free) "🆓 " else ""
            "$tag${it.name}   [$p]"
        })
    }

    private fun connect(link: String?) {
        pendingLink = link
        val prep = VpnService.prepare(this)
        if (prep != null) startActivityForResult(prep, 100) else startVpn(link)
    }

    private fun startVpn(link: String?) {
        val i = Intent(this, MyVpnService::class.java).setAction(MyVpnService.ACTION_START)
        link?.let { i.putExtra(MyVpnService.EXTRA_LINK, it) }
        startForegroundService(i)
        status.text = "در حال اتصال…"
        connecting = true
        updateConnectButton()
    }

    private fun disconnect() {
        connecting = false
        startService(Intent(this, MyVpnService::class.java).setAction(MyVpnService.ACTION_STOP))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) startVpn(pendingLink)
    }

    private fun pingAll() {
        servers.forEach { it.pingMs = 0 }
        render()
        lifecycleScope.launch {
            Pinger.testAll(servers) { render() }
            render()
            status.text = Pinger.best(servers)?.let { "بهترین: ${it.name} (${it.pingMs} ms)" } ?: "هیچ سروری پاسخ نداد"
        }
    }

    private fun findFree() {
        btnFree.isEnabled = false
        lifecycleScope.launch {
            val n = FreeServers.refresh(store) { status.text = it }
            reload()
            status.text = if (n > 0) "$n سرور رایگان سالم به لیست اضافه شد" else "سرور رایگان پیدا نشد"
            btnFree.isEnabled = true
        }
    }

    private fun addDialog() {
        val input = EditText(this).apply {
            hint = "لینک‌ها (vless/vmess/trojan/ss) یا لینک اشتراک http"
            minLines = 4
        }
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).primaryClip
            ?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()?.let { input.setText(it) }
        AlertDialog.Builder(this).setTitle("افزودن سرور").setView(input)
            .setPositiveButton("افزودن") { _, _ -> importText(input.text.toString()) }
            .setNegativeButton("لغو", null).show()
    }

    private fun importText(raw: String) {
        lifecycleScope.launch {
            val text = raw.trim()
            val body = if (text.startsWith("http")) {
                runCatching { withContext(Dispatchers.IO) { URL(text).readText() } }
                    .getOrElse { status.text = "دریافت اشتراک ناموفق بود"; return@launch }
            } else text
            val parsed = ConfigParser.parseMany(body)
            if (parsed.isEmpty()) { status.text = "لینک معتبری پیدا نشد"; return@launch }
            store.links = (store.links + parsed.map { it.link }).distinct()
            reload()
            status.text = "${parsed.size} سرور اضافه شد"
            pingAll()
        }
    }
}
