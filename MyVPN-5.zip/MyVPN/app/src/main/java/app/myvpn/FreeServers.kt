package app.myvpn

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/**
 * پیدا کردن خودکار سرور رایگان از اشتراک‌های عمومی (GitHub)،
 * تست پینگ واقعی و نگه داشتن چند سرور سالم در مجموعه.
 *
 * هشدار: سرور رایگان عمومی را افراد ناشناس اداره می‌کنند؛ برای کارهای حساس
 * (بانک، ایمیل، ورود به حساب‌های مهم) استفاده نکنید.
 */
object FreeServers {

    /** اگر لینکی از کار افتاد، می‌توانید اینجا لینک اشتراک جدید اضافه کنید */
    val SOURCES = listOf(
        "https://raw.githubusercontent.com/barry-far/V2ray-Config/main/All_Configs_Sub.txt",
        "https://raw.githubusercontent.com/Epodonios/v2ray-configs/main/All_Configs_Sub.txt",
        "https://raw.githubusercontent.com/MatinGhanbari/v2ray-CONFIGs/main/subscriptions/v2ray/super-sub.txt",
        "https://raw.githubusercontent.com/mahdibland/V2RayAggregator/master/sub/sub_merge.txt"
    )

    private const val MAX_LINES_PER_SOURCE = 400   // نمونه‌گیری تصادفی تا سرعت پایین نیاید
    private const val MAX_TO_TEST = 120
    private const val KEEP = 15

    private fun download(url: String): String? = runCatching {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12_000
        c.readTimeout = 20_000
        c.inputStream.bufferedReader().use { it.readText().take(6_000_000) }
    }.getOrNull()

    /** تعداد سرور سالمِ ذخیره‌شده را برمی‌گرداند */
    suspend fun refresh(store: Store, onProgress: (String) -> Unit = {}): Int {
        val found = LinkedHashMap<String, Server>()
        for ((i, src) in SOURCES.withIndex()) {
            onProgress("دریافت لیست ${i + 1}/${SOURCES.size}…")
            val text = withContext(Dispatchers.IO) { download(src) } ?: continue
            val parsed = withContext(Dispatchers.Default) { ConfigParser.parseMany(text) }
                .shuffled().take(MAX_LINES_PER_SOURCE)
            for (s in parsed) found.putIfAbsent(s.link, s)
        }
        if (found.isEmpty()) {
            onProgress("دریافت لیست رایگان ناموفق بود (اینترنت/دسترسی به GitHub)")
            return 0
        }
        val candidates = found.values.shuffled().take(MAX_TO_TEST)
        onProgress("تست پینگ ${candidates.size} سرور…")
        Pinger.testAll(candidates, concurrency = 16)

        val good = candidates.filter { it.pingMs > 0 }.sortedBy { it.pingMs }.take(KEEP)
        if (good.isNotEmpty()) {
            store.freeLinks = good.map { it.link }
        }
        onProgress("${good.size} سرور رایگان سالم پیدا شد")
        return good.size
    }
}
